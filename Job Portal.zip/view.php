<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous"><!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!-- Container wrapper -->
  <div class="container">
    <!-- Navbar brand -->
    <a class="navbar-brand me-2" href="https://mdbgo.com/">
      <img
        src="https://cdn1.vectorstock.com/i/thumb-large/17/05/j-letter-icon-for-job-search-portal-vector-23361705.jpg"
        height="50"
        width="80";
        alt="MDB Logo"
        loading="lazy"
        style="margin-top: -1px;"
      />
    </a>

    <!-- Toggle button -->
    <button
      class="navbar-toggler"
      type="button"
      data-mdb-toggle="collapse"
      data-mdb-target="#navbarButtonsExample"
      aria-controls="navbarButtonsExample"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <i class="fas fa-bars"></i>
    </button>

    <!-- Collapsible wrapper -->
    <div class="collapse navbar-collapse" id="navbarButtonsExample">
      <!-- Left links -->
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="#">Dashboard</a>
        </li>
      </ul>
       <button type="submit" name="login" class="btn btn-link px-3 me-2" >
          <a href="login1.php"
                class="link-danger">Login</a>
        </button>
        <button type="submit" name="signin"class="btn btn-primary me-3">
          <a href="register1.php"
                class="link-danger">Sign in</a>
        </button>
        
      </div>
    </div>
    <!-- Collapsible wrapper -->
  </div>
  <!-- Container wrapper -->
</nav>
    
    

    
           
<div class="banner-outer">
  <!-- Background image -->
<div
  class="bg-image"
  style="
    background-image: url('https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?ixlib=rb-1.2.1&ixid=MnwxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwxNnx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=600');
    
  "
>

    <div id="banner" style="background-color: #000000b3;" class="element kenburnsy fullscreen"></div>

    <div class="caption">

      <div class="holder" s><br><br><br><br><br><br><br><br>

       

        <form action="" method="post">

          <div class="container">

            <div class="row">

              
              

            </div>

          </div>

        </form><br>

                        
                        <center><div class="col-sm-2">
            <a href="login1.php" class="btn btn-primary">I Am Admin</a>
  
  <div class="col-sm-5"><br>
            <a href="login1.php" class="btn btn-primary">I Am User</a>
  </center>
  </div>
</div>

        

    </div>
    </div>
<!-- Background image -->

    <div class="browse-job-section">

 
    </div><br>

  </div>
  <!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
  </body>
</html>
