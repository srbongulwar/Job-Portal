<?php

$db_path="localhost";
$db_username="root";
$db_password="";
$db_name="onlinejob";

$conn=mysqli_connect($db_path,$db_username,$db_password,$db_name);



?>